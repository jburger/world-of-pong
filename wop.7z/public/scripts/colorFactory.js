var colorFactory = (function () {
    'use strict';
    return {
        sceneBackground: 0xfbcaa6
    };
})();
      